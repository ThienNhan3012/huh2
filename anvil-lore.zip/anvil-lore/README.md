# Anvil Lore (Fabric, MC 26.3)

Put an item in the anvil's left slot, type text in the name box, click **+ Lore**.
The text is appended as a lore line (max 10 lines x 50 chars), costs 1 XP level (free in creative).
The name box is cleared so the item isn't also renamed.

## Build
Requires JDK 25 and Gradle >= 9.1.
    gradle wrapper --gradle-version 9.1   # once, if there's no ./gradlew
    ./gradlew clean build                 # jar -> build/libs/anvil-lore-1.0.0.jar
    ./gradlew runClient                   # test in dev

## If it fails to compile (I couldn't run javap on the 26.3 jar)
Check these against the real jar: javap -p <class>
- AnvilScreen: field `name` (EditBox), method `subInit`
- ItemCombinerScreen ctor: (menu, Inventory, Component, Identifier)
- Player#hasInfiniteMaterials, ServerPlayer#sendOverlayMessage
- Fabric API: PayloadTypeRegistry.serverboundPlay, ClientPlayNetworking.send
- Loom plugin id/version in build.gradle
