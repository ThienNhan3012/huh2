package dev.anvillore;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Client -> server: "add this text as a lore line to the item in the anvil's left slot". */
public record AddLorePayload(String text) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<AddLorePayload> TYPE =
            new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath("anvillore", "add_lore"));

    public static final StreamCodec<RegistryFriendlyByteBuf, AddLorePayload> CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.stringUtf8(AnvilLore.MAX_LORE_LENGTH * 4), // utf8 bytes cap
                    AddLorePayload::text,
                    AddLorePayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
