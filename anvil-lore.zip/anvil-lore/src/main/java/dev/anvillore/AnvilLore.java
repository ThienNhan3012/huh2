package dev.anvillore;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;

public class AnvilLore implements ModInitializer {
    public static final int MAX_LORE_LENGTH = 50;
    public static final int MAX_LORE_LINES = 10;
    public static final int LEVEL_COST = 1;

    @Override
    public void onInitialize() {
        // Register on BOTH sides (this entrypoint runs everywhere) so the codec is known to the client too.
        PayloadTypeRegistry.serverboundPlay().register(AddLorePayload.TYPE, AddLorePayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(AddLorePayload.TYPE, (payload, context) ->
                // Handlers run on the server thread in modern Fabric API; execute() keeps it safe either way.
                context.player().level().getServer().execute(() -> handle(context.player(), payload.text())));
    }

    /** Never trust the client: re-validate everything here. */
    private static void handle(ServerPlayer player, String raw) {
        if (!(player.containerMenu instanceof AnvilMenu menu) || !menu.stillValid(player)) return;

        String text = raw == null ? "" : raw.strip();
        if (text.isEmpty() || text.length() > MAX_LORE_LENGTH) return;

        Slot input = menu.getSlot(0); // AnvilMenu: 0 = left input, 1 = right input, 2 = result
        ItemStack stack = input.getItem();
        if (stack.isEmpty()) return;

        ItemLore lore = stack.getOrDefault(DataComponents.LORE, ItemLore.EMPTY);
        if (lore.lines().size() >= MAX_LORE_LINES) {
            player.sendOverlayMessage(Component.literal("This item already has the maximum lore lines."));
            return;
        }

        boolean free = player.hasInfiniteMaterials(); // creative
        if (!free && player.experienceLevel < LEVEL_COST) {
            player.sendOverlayMessage(Component.literal("Needs " + LEVEL_COST + " experience level."));
            return;
        }

        stack.set(DataComponents.LORE, lore.withLineAdded(Component.literal(text)));
        if (!free) player.giveExperienceLevels(-LEVEL_COST);

        input.setChanged();        // recomputes the anvil result
        menu.broadcastChanges();   // syncs to the client
    }
}
