package dev.anvillore.client.mixin;

import dev.anvillore.AddLorePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AnvilScreen;
import net.minecraft.client.gui.screens.inventory.ItemCombinerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AnvilMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Adds a small "+ Lore" button next to the anvil GUI.
 * Extends the superclass only so we can call protected addRenderableWidget / read leftPos etc.
 * (The dummy ctor is never run; Mixin discards it.)
 */
@Mixin(AnvilScreen.class)
public abstract class AnvilScreenMixin extends ItemCombinerScreen<AnvilMenu> {

    @Shadow private EditBox name;

    private AnvilScreenMixin(AnvilMenu menu, Inventory inv, Component title, Identifier texture) {
        super(menu, inv, title, texture);
    }

    @Inject(method = "subInit", at = @At("TAIL"))
    private void anvillore$addLoreButton(CallbackInfo ci) {
        Button button = Button.builder(Component.literal("+ Lore"), b -> {
                    String text = this.name.getValue().strip();
                    if (text.isEmpty()) return;
                    ClientPlayNetworking.send(new AddLorePayload(text));
                    this.name.setValue(""); // don't also rename the item
                })
                .bounds(this.leftPos + this.imageWidth + 4, this.topPos + 20, 50, 20)
                .tooltip(net.minecraft.client.gui.components.Tooltip.create(
                        Component.literal("Adds the name-box text as a lore line (1 level)")))
                .build();
        this.addRenderableWidget(button);
    }
}
